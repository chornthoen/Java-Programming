package abstract_shape;

abstract public class Shape {
    abstract double getParameter();
    abstract double getArea();
}
