package abstract_class_employee;

import javax.swing.*;

public class TestEmployee {
    Employee employee;
    String report=" ";
    void out(String m){
        JOptionPane.showMessageDialog(null,m);
    }
    public TestEmployee(){
        employee = new PartTime();
        report+=employee.toString()+"\n";
        employee = new FullTime();
        report+=employee.toString()+"\n";
        employee= new Sale();
        report+=employee.toString();
        out(report);
    }

    public static void main(String[] args) {
        new TestEmployee();
    }
}
